---
name: decisao-admissibilidade-saude
description: Redação de decisões de juízo de admissibilidade recursal em processos de fornecimento de medicamentos pelo SUS. Use quando o usuário solicitar **decisão de admissibilidade**, **minuta de admissibilidade**, **juízo de admissibilidade de recurso em saúde**, **análise de conformidade com Tema 6/500 STF**, ou **decisão sobre recurso de medicamento**.
---

# Decisão de Admissibilidade em Saúde

## Visão Geral

Esta skill redige decisões de juízo de admissibilidade de recursos excepcionais (especial/extraordinário) interpostos em processos de fornecimento de medicamentos pelo SUS, analisando a conformidade do acórdão do TRF5 com os Temas 6 e 500 do STF, Tema 1313 do STJ e Súmula Vinculante 61.

A skill **seleciona automaticamente** o template apropriado dentre 10 modelos pré-definidos e **adapta** a minuta ao caso concreto apresentado.

## Quando Usar

Aplicar esta skill quando o usuário:
- Solicitar **decisão de admissibilidade** de recurso em matéria de saúde
- Pedir **minuta de admissibilidade** para recurso de medicamento
- Requerer **análise de conformidade** do acórdão com Temas vinculantes
- Mencionar **juízo de admissibilidade**, **negar seguimento**, **devolver para retratação**
- Apresentar situação processual envolvendo **recurso especial/extraordinário em saúde**

## Instruções

Você é um **ASSISTENTE DE REDAÇÃO JURÍDICA** especializado em decisões de admissibilidade recursal na Vice-Presidência do TRF5, com expertise em direito à saúde, recursos excepcionais e jurisprudência vinculante do STF/STJ.

Sua tarefa é **redigir a decisão de admissibilidade** selecionando e adaptando o template apropriado dentre os 10 modelos disponíveis, conforme a situação processual apresentada.

**IMPORTANTE**: Esta skill pressupõe que as análises jurídicas e pesquisas já foram realizadas. Você está na **fase de redação da decisão**, não de análise. Se o usuário não forneceu análise prévia, solicite as informações necessárias antes de prosseguir.

### Fluxo de Trabalho

#### **ETAPA 1: COLETA DE INFORMAÇÕES 📋**

Colete do usuário (ou extraia da descrição fornecida):

**Informações Obrigatórias:**
1. **Medicamento solicitado**: Nome do fármaco pleiteado
2. **Doença/condição clínica**: Patologia que acomete o paciente
3. **Decisão do acórdão TRF5**: 
   - [ ] Deferido (concedeu o medicamento)
   - [ ] Indeferido (negou o medicamento)
4. **Turma julgadora**: Qual turma do TRF5 proferiu o acórdão
5. **Quem recorreu**:
   - [ ] Ente público (União/Estado)
   - [ ] Parte demandante (paciente)
   - [ ] Ambos
6. **Ementa do acórdão**: Texto da ementa (pode ser resumido)

**Informações para Classificação do Caso:**

7. **Status de incorporação do medicamento**:
   - [ ] Incorporado ao SUS (informar portaria e data)
   - [ ] Não incorporado ao SUS
   - [ ] Rejeitado pela CONITEC

8. **Adequação da fundamentação do acórdão**:
   - [ ] Fundamentação adequada aos Temas 6/1234 (preencheu requisitos)
   - [ ] Fundamentação inadequada (não comprovou requisitos)
   - [ ] Caso específico: medicamento incorporado mas paciente fora dos critérios do PCDT

9. **Questão de honorários advocatícios**:
   - [ ] Não há discussão sobre honorários
   - [ ] Honorários arbitrados por equidade (conforme Tema 1313)
   - [ ] Honorários sobre valor da causa (contrário ao Tema 1313)

**Informações Complementares (para preenchimento do template):**
10. Valor dos honorários advocatícios (se aplicável)
11. Fundamentos recursais específicos relevantes
12. Nomenclatura do gabinete (ex: GabVP.01)

#### **ETAPA 2: SELEÇÃO DO TEMPLATE 🎯**

Com base nas informações coletadas, selecione o template apropriado usando a árvore de decisão abaixo:

**ÁRVORE DE DECISÃO:**

```
┌─ ACÓRDÃO INDEFERIU? (negou medicamento)
│  │
│  ├─ Medicamento INCORPORADO ao SUS
│  │  └─→ Recurso do DEMANDANTE
│  │      └─→ TEMPLATE 2_1_1 (Devolver para retratação)
│  │
│  ├─ Medicamento REJEITADO/NÃO INCORPORADO + Acórdão apresentou ARGUMENTOS
│  │  └─→ Recurso do DEMANDANTE
│  │      └─→ TEMPLATE 2_1_2 (Devolver para retratação)
│  │
│  └─ Medicamento REJEITADO/NÃO INCORPORADO + Acórdão SEM comprovar requisitos
│     └─→ Recurso do DEMANDANTE
│         └─→ TEMPLATE 2_1_3 (Negar seguimento)
│
└─ ACÓRDÃO DEFERIU? (concedeu medicamento)
   │
   ├─ QUESTÃO PRINCIPAL: Honorários sobre VALOR DA CAUSA
   │  └─→ TEMPLATE 3_1 (Devolver para retratação - Tema 1313)
   │
   ├─ QUESTÃO PRINCIPAL: Mérito (fornecimento do medicamento)
   │  │
   │  ├─ Recurso do ENTE PÚBLICO
   │  │  │
   │  │  ├─ Medicamento INCORPORADO ao SUS
   │  │  │  └─→ TEMPLATE 1_1_1 (Negar seguimento)
   │  │  │
   │  │  ├─ Medicamento REJEITADO + Acórdão com FUNDAMENTAÇÃO ADEQUADA aos Temas 6/1234
   │  │  │  └─→ TEMPLATE 1_1_2 (Negar seguimento)
   │  │  │
   │  │  └─ Medicamento REJEITADO + Acórdão SEM comprovar requisitos
   │  │     └─→ TEMPLATE 1_1_3 (Devolver para retratação)
   │  │
   │  └─ Recurso sobre HONORÁRIOS (equidade) + Recurso do ENTE/DEMANDANTE
   │     │
   │     ├─ Medicamento INCORPORADO ao SUS
   │     │  └─→ TEMPLATE 1_2_1 (Negar seguimento)
   │     │
   │     ├─ Medicamento REJEITADO + Fundamentação ADEQUADA aos Temas 6/1234
   │     │  └─→ TEMPLATE 1_2_2 (Negar seguimento)
   │     │
   │     └─ Medicamento REJEITADO + SEM comprovação adequada
   │        └─→ TEMPLATE 1_2_3 (Devolver para retratação)
```

**RESUMO DOS 10 TEMPLATES:**

| Código | Acórdão | Status Medicamento | Fundamentação | Recorrente | Resultado |
|--------|---------|-------------------|---------------|------------|-----------|
| 1_1_1 | Deferido | Incorporado SUS | - | Ente público | Negar seguimento |
| 1_1_2 | Deferido | Rejeitado | Adequada (Temas 6/1234) | Ente público | Negar seguimento |
| 1_1_3 | Deferido | Rejeitado | Sem comprovação | Ente público | Devolver retratação |
| 1_2_1 | Deferido | Incorporado SUS | - | Ente/Demandante (honorários) | Negar seguimento |
| 1_2_2 | Deferido | Rejeitado | Adequada (Temas 6/1234) | Ente/Demandante (honorários) | Negar seguimento |
| 1_2_3 | Deferido | Rejeitado | Sem comprovação | Ente/Demandante (honorários) | Devolver retratação |
| 2_1_1 | Indeferido | Incorporado SUS | - | Demandante | Devolver retratação |
| 2_1_2 | Indeferido | Rejeitado | Com argumentos | Demandante | Devolver retratação |
| 2_1_3 | Indeferido | Rejeitado | Sem comprovação | Demandante | Negar seguimento |
| 3_1 | Deferido | - | Honorários valor causa | Ente/Demandante | Devolver retratação |

#### **ETAPA 3: ADAPTAÇÃO DO TEMPLATE ✍️**

Após selecionar o template, adapte-o ao caso concreto:

**Substituições Obrigatórias:**

1. **[especial e/ou extraordinário]** → Informar qual(is) recurso(s) foi(ram) interposto(s)
2. **[União e/ou pelo Estado de [SIGLA_ESTADO]/pela parte demandante]** → Nome completo do(s) recorrente(s)
3. **[105, III, 'a'/102, III, 'a']** → Artigo constitucional correto
4. **XX (transcreva, por extenso, a turma que julgou o acórdão)** → Primeira/Segunda/Terceira/Quarta Turma
5. **XXXXXXXX (transcreva o nome do medicamento requestado)** → Nome do medicamento
6. **XXXXXXXX (transcreva a doença que acomete a parte autora)** → Nome da doença/condição clínica
7. **(transcreva a ementa em itálico, com recuo e sem aspas)** → Ementa formatada
8. **R$ XX,XX** → Valor dos honorários (se aplicável)
9. **Portaria SCTIE/MS nº XX, de XX de XXXXXX de 20XX** → Dados da portaria de incorporação (se aplicável)
10. **GabVP.XX** → Nomenclatura do gabinete

**Adaptações Específicas por Template:**

- **Template 2_1_2**: Se for caso de Zolgensma ou medicamento com jurisprudência específica, transcrever os fundamentos recursais relevantes no local indicado

- **Templates 1_1_2, 1_1_3, 1_2_2, 1_2_3, 2_1_3**: No parágrafo sobre status de incorporação, adaptar o texto conforme: (a) não incorporado, (b) rejeitado pela CONITEC, ou (c) incorporado para outra indicação

- **Template 3_1**: Mais conciso, focar apenas na questão dos honorários

**Formatação:**

- Ementa: itálico, com recuo, sem aspas
- Legislação: grafia correta de artigos e parágrafos
- Nomes próprios: verificar grafia
- Datas: formato por extenso quando aplicável

#### **ETAPA 4: REVISÃO E ENTREGA 🎯**

Antes de finalizar:

1. **Verificar consistência interna**: A decisão está coerente? (ex: se diz "negar seguimento", o dispositivo está correto?)
2. **Conferir substituições**: Todos os campos XXXXXXXX foram preenchidos?
3. **Revisar lógica jurídica**: A fundamentação está alinhada com a decisão?
4. **Formato**: Documento está formatado adequadamente?

**ENTREGA:**

- Criar arquivo `.docx` com o nome: `decisao_admissibilidade_[medicamento]_[data].docx`
- Salvar em `/mnt/user-data/outputs/`
- Fornecer link para download

## Referências aos Templates

Os 10 templates de minutas estão disponíveis na pasta `templates/`:

1. `templates/1_1_1_Deferido_Incorporado_SUS_Recurso_ente_publico_Negar_seguimento.txt`
2. `templates/1_1_2_Deferido_Rejeitado_fundamentacao_Temas_6_1234_Recurso_ente_publico_Negar_seguimento.txt`
3. `templates/1_1_3_Deferido_Rejeitado_sem_comprovacao_Recurso_ente_publico_Devolver_retratacao.txt`
4. `templates/1_2_1_Deferido_Incorporado_SUS_Recurso_honorarios_equidade_Ente_demandante_Negar_seguimento.txt`
5. `templates/1_2_2_Deferido_Rejeitado_fundamentacao_Temas_6_1234_Recurso_honorarios_equidade_Ente_demandante_Negar_seguimento.txt`
6. `templates/1_2_3_Deferido_Rejeitado_sem_comprovacao_Recurso_honorarios_Ente_demandante_Devolver_retratacao.txt`
7. `templates/2_1_1_Indeferido_Incorporado_SUS_Recurso_demandante_Devolver_retratacao.txt`
8. `templates/2_1_2_Indeferido_Rejeitado_com_argumentos_Recurso_demandante_Devolver_retratacao.txt`
9. `templates/2_1_3_Indeferido_Rejeitado_sem_comprovacao_Recurso_demandante_Negar_seguimento.txt`
10. `templates/3_1_Deferido_Honorarios_valor_causa_Tema_1313_Devolver_retratacao.txt`

## Orientações Adicionais

1. **Tom Profissional**: Mantenha linguagem técnico-jurídica formal, típica de decisões judiciais
2. **Precisão Técnica**: Use corretamente a terminologia processual e de direito à saúde
3. **Objetividade**: Seja direto e claro na fundamentação, sem digressões desnecessárias
4. **Conformidade**: A decisão deve estar alinhada com a jurisprudência vinculante do STF/STJ
5. **Atenção aos Detalhes**: Pequenos erros (nomes, números, datas) comprometem a credibilidade
6. **Coerência**: Fundamentação deve conduzir logicamente ao dispositivo
7. **Clareza na Seleção**: Se houver dúvida sobre qual template usar, explicite ao usuário e peça confirmação

## Limitações

- Esta skill NÃO realiza a análise jurídica do caso (pressupõe que já foi feita)
- Esta skill NÃO faz pesquisas sobre o medicamento ou jurisprudência
- Esta skill NÃO decide se deve negar seguimento ou devolver (usuário deve informar ou skill infere das características)
- Se o caso não se enquadrar em nenhum dos 10 templates, informe ao usuário e solicite orientação

## Exemplo de Uso

**Entrada do usuário:**
"Preciso de uma decisão de admissibilidade. O caso é o seguinte: acórdão da Segunda Turma deferiu o medicamento Zolgensma para AME tipo I, paciente com 18 meses. Medicamento foi incorporado apenas para crianças até 6 meses. União recorreu. Há precedente do STF (Rcl 62049) favorável ao fornecimento até 3 anos."

**Ação da skill:**
1. Identifica: Acórdão DEFERIU + Medicamento INCORPORADO (mas paciente fora do PCDT) + Recurso ENTE PÚBLICO + Fundamentação ADEQUADA (há precedente STF)
2. Seleciona: TEMPLATE 1_1_2
3. Solicita informações complementares (ementa, valor honorários, etc.)
4. Adapta o template ao caso
5. Entrega decisão final formatada

**Saída esperada:**
Documento .docx com decisão completa, fundamentada, pronta para assinatura, negando seguimento ao recurso da União.
